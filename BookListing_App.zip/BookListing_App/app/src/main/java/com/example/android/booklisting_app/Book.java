package com.example.android.booklisting_app;

import android.graphics.Bitmap;

public class Book {
    private String mBookTitle;
    private String[] mBookAuthors;
    private String mBookDescription;
    private String mUrl;
    private Bitmap mBookImage;

    public Book(String bookTitle, String[] bookAuthors, String bookDescription, String url, Bitmap bookImage) {
        mBookTitle = bookTitle;
        mBookAuthors = bookAuthors;
        mBookDescription = bookDescription;
        mUrl = url;
        mBookImage = bookImage;
    }

    public String getBookTitle() {
        return mBookTitle;
    }

    public String[] getAuthors() {
        return mBookAuthors;
    }

    public String generateStringOfAuthor() {
        String s = "";
        for (int i = 0; i < mBookAuthors.length; i++) {
            if (i == mBookAuthors.length - 1)
                s += mBookAuthors[i];
            else
                s += mBookAuthors[i] + ", ";
        }
        return s;
    }

    public String getBookDescription() {
        return mBookDescription;
    }

    public String geturl() {
        return mUrl;
    }

    public Bitmap getmBookImage() {
        return mBookImage;
    }
}

