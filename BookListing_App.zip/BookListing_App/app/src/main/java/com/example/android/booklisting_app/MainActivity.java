package com.example.android.booklisting_app;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<Book>> {
    private RecyclerView mRecyclerView;
    private Button mSearchButton;
    private TextView mInfoAlarm;
    private EditText mEditText;

    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ConnectivityManager cm;
    private NetworkInfo activeNetwork;
    public static final String LOG_TAG = MainActivity.class.getSimpleName();
    ProgressBar progress;

    public static final int BOOK_LOADER_ID = 1;
    private static final String BOOK_REQUEST_URL = "https://www.googleapis.com/books/v1/volumes?q=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mSearchButton = (Button) findViewById(R.id.btn_search);
        mInfoAlarm = (TextView) findViewById(R.id.textview_alarm);
        mEditText = (EditText) findViewById(R.id.edit_text_search);
        cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        mRecyclerView.setHasFixedSize(true);
        progress = (ProgressBar) findViewById(R.id.progress_bar);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        LoaderManager loaderManager = getLoaderManager();
        loaderManager.initLoader(BOOK_LOADER_ID, null, this);

        mAdapter = new BookAdapter(new ArrayList<Book>(), new BookAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Book book) {
            }
        });
        mRecyclerView.setAdapter(mAdapter);
        progress.setVisibility(View.GONE);
        mSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mRecyclerView.setAdapter(null);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                activeNetwork = cm.getActiveNetworkInfo();
                if (activeNetwork != null && activeNetwork.isConnectedOrConnecting()) {
                    getLoaderManager().restartLoader(BOOK_LOADER_ID, null, MainActivity.this);
                    progress.setVisibility(View.VISIBLE);
                } else {
                    Toast toast = Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_internet), Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });
    }

    @Override
    public Loader<ArrayList<Book>> onCreateLoader(int id, Bundle args) {
        String searchInput = mEditText.getText().toString();
        try {
            searchInput = URLEncoder.encode(searchInput, "UTF-8");
        } catch (IOException e) {
            Log.e(LOG_TAG, "Error url encoding: ", e);
            searchInput = "";
        }

        String url = BOOK_REQUEST_URL + searchInput + "&maxResults=20";
        return new BookLoader(MainActivity.this, url);
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<Book>> loader, ArrayList<Book> books) {
        if (books == null) {
            mAdapter = new BookAdapter(new ArrayList<Book>(), new BookAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(Book book) {
                }
            });
            mRecyclerView.setAdapter(mAdapter);
            mInfoAlarm.setVisibility(View.VISIBLE);
            return;
        }
        mAdapter = new BookAdapter(books, new BookAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Book book) {
                String url = book.geturl();
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        mRecyclerView.setAdapter(mAdapter);
        mInfoAlarm.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<Book>> loader) {
        mRecyclerView.setAdapter(null);
    }
}

